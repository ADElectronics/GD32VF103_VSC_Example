# IAR RISC-V GD32V EVAL - Interrupt-driven switches example

This example uses EXTI interrupts to check whenever S1, S2 or S3 are pressed, then the corresponding LED toggles.

