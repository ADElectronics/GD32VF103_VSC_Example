# IAR RISC-V GD32V EVAL - Toggle GPIO example

This project is an example which toggles an LED available on a GPIO pin. 
  
