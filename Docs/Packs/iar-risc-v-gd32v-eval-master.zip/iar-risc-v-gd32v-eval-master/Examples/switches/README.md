# IAR RISC-V GD32V EVAL - Switches example

This example performs polling to check whenever S1, S2 or S3 are pressed, then the corresponding LED is toggled.

